//
//  DetailTableViewController.h
//  DivyabhaskarApp
//
//  Created by MAC on 8/11/15.
//  Copyright (c) 2015 MAC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailTableViewController : UITableViewController<UITableViewDataSource,UITableViewDelegate>
{
    NSArray *arrtitle;
    NSArray *arrlink;
    NSMutableArray *arrmute;
    NSMutableDictionary *dictmute;
}
@end
