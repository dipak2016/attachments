//
//  ViewController.h
//  DivyabhaskarApp
//
//  Created by MAC on 8/11/15.
//  Copyright (c) 2015 ___FULLUSERNAME___. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextView *txt_vw;
@property (retain,nonatomic)NSString *st_get;
@end
