//
//  NewTableViewController.h
//  DivyabhaskarApp
//
//  Created by MAC on 8/11/15.
//  Copyright (c) 2015 MAC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewTableViewController : UITableViewController<UITableViewDataSource,UITableViewDelegate,NSXMLParserDelegate,UIAlertViewDelegate>
{
    NSMutableString *title;
    NSMutableString *sdesc;
    NSMutableString *desc;
    NSMutableArray *arrmute;
    NSMutableDictionary *dictmute;
    NSString *elemntnm;
}
@property (retain,nonatomic)NSString *sturl;
@property (strong, nonatomic) IBOutlet UITableView *tblvw;
@end
