//
//  NewTableViewController.m
//  DivyabhaskarApp
//
//  Created by MAC on 8/11/15.
//  Copyright (c) 2015 MAC. All rights reserved.
//

#import "NewTableViewController.h"
#import "ViewController.h"
@interface NewTableViewController ()

@end

@implementation NewTableViewController
@synthesize sturl,tblvw;
- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    arrmute=[[NSMutableArray alloc]init];
    NSXMLParser *parser=[[NSXMLParser alloc]initWithContentsOfURL:[NSURL URLWithString:sturl]];
    parser.delegate=self;
    [parser parse];
    
}
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
    elemntnm=elementName;
    if ([elementName isEqualToString:@"NewsHeadline"])
    {
        title=[[NSMutableString alloc]init];
        sdesc=[[NSMutableString alloc]init];
        desc=[[NSMutableString alloc]init];
        dictmute=[[NSMutableDictionary alloc]init];
    }
    
}
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    if ([elemntnm isEqualToString:@"title"])
    {
        [title appendString:string];
    }
    if ([elemntnm isEqualToString:@"shortDescription"])
    {
        [sdesc appendString:string];
    }
    if ([elemntnm isEqualToString:@"description"])
    {
        [desc appendString:string];
    }
}
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    if ([elementName isEqualToString:@"NewsHeadline"])
    {
        [dictmute setObject:title forKey:@"title"];
        [dictmute setObject:sdesc forKey:@"sdesc"];
        [dictmute setObject:desc forKey:@"desc"];
        [arrmute addObject:[dictmute copy]];
    }
}
- (void)parserDidEndDocument:(NSXMLParser *)parser
{
    /*
    for (int i=0;i<arrmute.count;i++)
    {
        NSLog(@"INDEX:%d VALUE:%@",i,[arrmute objectAtIndex:i]);
    }
    */
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return arrmute.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = nil;
    cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    cell.textLabel.text=[[arrmute objectAtIndex:indexPath.row]objectForKey:@"title"];
    // Configure the cell...
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UIAlertView *alrt=[[UIAlertView alloc]initWithTitle:@"Alert" message:[[arrmute objectAtIndex:indexPath.row]objectForKey:@"sdesc"] delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"MORE", nil];
    [alrt show];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    ViewController *vc=[self.storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
    NSIndexPath *ind=[tblvw indexPathForSelectedRow];
    vc.st_get=[[arrmute objectAtIndex:ind.row]objectForKey:@"desc"];
    [self.navigationController pushViewController:vc animated:YES];
}   
/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
