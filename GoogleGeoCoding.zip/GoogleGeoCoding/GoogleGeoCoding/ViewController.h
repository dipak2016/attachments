//
//  ViewController.h
//  GoogleGeoCoding
//
//  Created by MAC on 9/29/15.
//  Copyright (c) 2015 ___FULLUSERNAME___. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *txt_place;
- (IBAction)btn_action:(id)sender;
@property (weak, nonatomic) IBOutlet MKMapView *mapvw;

@end
