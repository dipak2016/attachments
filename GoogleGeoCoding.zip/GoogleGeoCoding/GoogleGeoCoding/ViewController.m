//
//  ViewController.m
//  GoogleGeoCoding
//
//  Created by MAC on 9/29/15.
//  Copyright (c) 2015 ___FULLUSERNAME___. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize txt_place,mapvw;
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(MKAnnotationView *)mapView:(MKMapView *)mV viewForAnnotation:(id <MKAnnotation>)annotation
{
    MKAnnotationView *pinView = nil;
    if(annotation != mapvw.userLocation)
    {
        static NSString *defaultPinID = @"com.invasivecode.pin";
        pinView = (MKAnnotationView *)[mapvw dequeueReusableAnnotationViewWithIdentifier:defaultPinID];
        if ( pinView == nil )
            pinView = [[MKAnnotationView alloc]
                       initWithAnnotation:annotation reuseIdentifier:defaultPinID];
        
        //pinView.pinColor = MKPinAnnotationColorGreen;
        pinView.canShowCallout = YES;
        //pinView.animatesDrop = YES;
        pinView.image = [UIImage imageNamed:@"1443527145_Map-Marker-Flag--Pink.png"];    //as suggested by Squatch
    }
    else {
        [mapvw.userLocation setTitle:@"I am here"];
    }
    return pinView;
}
- (IBAction)btn_action:(id)sender
{
    [self.view endEditing:YES];
    NSString *st=[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/geocode/json?address=%@",[txt_place.text stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    NSURL *url=[[NSURL alloc]initWithString:st];
    NSData *data=[[NSData alloc]initWithContentsOfURL:url];
    NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
    /*
    for (id ids in dict)
    {
        //NSLog(@"KEY:%@ VALUE:%@",ids,[dict objectForKey:ids]);
    }
    */
    NSLog(@"lat:%@",[[[[[dict objectForKey:@"results"]objectAtIndex:0]objectForKey:@"geometry"]objectForKey:@"location"]objectForKey:@"lat"]);
    NSLog(@"lng:%@",[[[[[dict objectForKey:@"results"]objectAtIndex:0]objectForKey:@"geometry"]objectForKey:@"location"]objectForKey:@"lng"]);
    
    CLLocationCoordinate2D loc;
    loc.latitude=[[[[[[dict objectForKey:@"results"]objectAtIndex:0]objectForKey:@"geometry"]objectForKey:@"location"]objectForKey:@"lat"]floatValue];
    loc.longitude=[[[[[[dict objectForKey:@"results"]objectAtIndex:0]objectForKey:@"geometry"]objectForKey:@"location"]objectForKey:@"lng"]floatValue];
    
    MKCoordinateRegion regin;
    regin.center=loc;
    regin.span.latitudeDelta=0.09;
    regin.span.longitudeDelta=0.09;
    
    MKPointAnnotation *newAnnotation = [[MKPointAnnotation alloc]init];
    newAnnotation.title=[[[dict objectForKey:@"results"]objectAtIndex:0]objectForKey:@"formatted_address"];
    newAnnotation.coordinate=loc;
    
    [mapvw addAnnotation:newAnnotation];
    [mapvw setRegion:regin];
    [mapvw regionThatFits:regin];
}
@end
