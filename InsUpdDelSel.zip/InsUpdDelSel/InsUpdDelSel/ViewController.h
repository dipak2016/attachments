//
//  ViewController.h
//  InsUpdDelSel
//
//  Created by MAC on 8/4/15.
//  Copyright (c) 2015 ___FULLUSERNAME___. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "dboperation.h"
@interface ViewController : UIViewController<UIAlertViewDelegate,UITableViewDataSource,UITableViewDelegate>
{
    dboperation *dbop;
    NSMutableArray *arrmain;
    NSString *st_get_id;
}
@property (weak, nonatomic) IBOutlet UITextField *txt_nm;
@property (weak, nonatomic) IBOutlet UITextField *txt_ct;
@property (weak, nonatomic) IBOutlet UITextField *txt_edu;
@property (weak, nonatomic) IBOutlet UITableView *tblvw;
- (IBAction)btn_action:(id)sender;
- (IBAction)btn_edit:(id)sender;
-(void)ClearAll;
-(void)SelectAll;
@end
