//
//  ViewController.m
//  InsUpdDelSel
//
//  Created by MAC on 8/4/15.
//  Copyright (c) 2015 ___FULLUSERNAME___. All rights reserved.
//

#import "ViewController.h"
#import "CustomTableViewCell.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize txt_ct,txt_edu,txt_nm,tblvw;
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    dbop=[[dboperation alloc]init];
    arrmain=[[NSMutableArray alloc]init];
    [self SelectAll];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)SelectAll
{
    arrmain=[dbop SelectAllData:@"select st_id,st_nm,st_city,st_edu from stud"];
    [tblvw reloadData];
}
- (IBAction)btn_action:(id)sender
{
    [self.view endEditing:YES];
    NSString *stmsg=@"";
    NSString *query=[NSString stringWithFormat:@"insert into stud(st_nm,st_city,st_edu)values('%@','%@','%@')",txt_nm.text,txt_ct.text,txt_edu.text];
    BOOL result=[dbop InsUpdDel:query];
    if(result==YES)
    {
        stmsg=@"Inserted...";
    }
    else
    {
        stmsg=@"Failed...";
    }
    UIAlertView *alrt=[[UIAlertView alloc]initWithTitle:@"Message" message:stmsg delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
    [alrt show];
}

- (IBAction)btn_edit:(id)sender
{
    [self.view endEditing:YES];
    if (st_get_id.length>0)
    {
        NSString *stmsg=@"";
        NSString *query=[NSString stringWithFormat:@"update stud set st_nm='%@',st_city='%@',st_edu='%@' where st_id='%@'",txt_nm.text,txt_ct.text,txt_edu.text,st_get_id];
        BOOL result=[dbop InsUpdDel:query];
        if(result==YES)
        {
            stmsg=@"Updated...";
        }
        else
        {
            stmsg=@"Failed...";
        }
        UIAlertView *alrt=[[UIAlertView alloc]initWithTitle:@"Message" message:stmsg delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [alrt show];
    }
}
-(void)ClearAll
{
    txt_nm.text=@"";
    txt_ct.text=@"";
    txt_edu.text=@"";
    st_get_id=@"";
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [self ClearAll];
    [self SelectAll];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrmain.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CustomTableViewCell *cell=nil;
    cell=[tableView dequeueReusableCellWithIdentifier:@"custom" forIndexPath:indexPath];
    cell.lbl_nm.text=[[arrmain objectAtIndex:indexPath.row]objectForKey:@"stnm"];
    [cell.btn_del addTarget:self action:@selector(btn_click:) forControlEvents:UIControlEventTouchUpInside];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSArray *arrsel=[[NSArray alloc]init];
    NSString *query=[NSString stringWithFormat:@"select st_id,st_nm,st_city,st_edu from stud where st_id='%@'",[[arrmain objectAtIndex:indexPath.row]objectForKey:@"stid"]];
    arrsel=[dbop SelectAllData:query];
    if(arrsel.count>0)
    {
        txt_nm.text=[[arrsel objectAtIndex:0]objectForKey:@"stnm"];
        txt_ct.text=[[arrsel objectAtIndex:0]objectForKey:@"stct"];
        txt_edu.text=[[arrsel objectAtIndex:0]objectForKey:@"stedu"];
        st_get_id=[[arrsel objectAtIndex:0]objectForKey:@"stid"];
    }
}
-(void)btn_click:(id)sender
{
    UITableView *tbl=(UITableView *)[[[[[sender superview]superview]superview]superview]superview];
    
    UITableViewCell *cell=(UITableViewCell *)[[[sender superview]superview]superview];
    
    NSIndexPath *ind=[tbl indexPathForCell:cell];
    
    NSLog(@"%d",ind.row);
    
    NSString *stmsg=@"";
    
    NSString *query=[NSString stringWithFormat:@"Delete from stud  where st_id='%@'",[[arrmain objectAtIndex:ind.row]objectForKey:@"stid"]];
    
    BOOL result=[dbop InsUpdDel:query];
    if(result==YES)
    {
        stmsg=@"Deleted...";
    }
    else
    {
        stmsg=@"Failed...";
    }
    UIAlertView *alrt=[[UIAlertView alloc]initWithTitle:@"Message" message:stmsg delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
    [alrt show];

    NSLog(@"click");
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}
@end
