//
//  dboperation.h
//  InsUpdDelSel
//
//  Created by MAC on 8/4/15.
//  Copyright (c) 2015 MAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AppDelegate.h"
#import <sqlite3.h>
@interface dboperation : NSObject
{
    AppDelegate *deli;
    sqlite3 *dbsql;
}
@property(retain,nonatomic)NSString *st_getpath;
-(BOOL)InsUpdDel:(NSString *)Query;
-(NSMutableArray *)SelectAllData:(NSString *)Query;
@end
