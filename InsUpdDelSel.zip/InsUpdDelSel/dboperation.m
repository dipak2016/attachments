//
//  dboperation.m
//  InsUpdDelSel
//
//  Created by MAC on 8/4/15.
//  Copyright (c) 2015 MAC. All rights reserved.
//

#import "dboperation.h"

@implementation dboperation
-(id)init
{
    if(self==[super init])
    {
    deli=(AppDelegate *)[[UIApplication sharedApplication]delegate];
        self.st_getpath=[NSString stringWithString:deli.dbpath];
    }
    return self;
}
-(BOOL)InsUpdDel:(NSString *)Query
{
    BOOL result=NO;
    if (sqlite3_open([self.st_getpath UTF8String],&dbsql)==SQLITE_OK)
    {
        sqlite3_stmt *ppStmt;
        if(sqlite3_prepare_v2(dbsql,[Query UTF8String],-1,&ppStmt,nil)==SQLITE_OK)
        {
            sqlite3_step(ppStmt);
            result=YES;
        }
        sqlite3_finalize(ppStmt);
    }
    sqlite3_close(dbsql);
    return result;
}
-(NSMutableArray *)SelectAllData:(NSString *)Query
{
    NSMutableArray *result=[[NSMutableArray alloc]init];
    NSMutableDictionary *dictmute=[[NSMutableDictionary alloc]init];
    if (sqlite3_open([self.st_getpath UTF8String],&dbsql)==SQLITE_OK)
    {
        sqlite3_stmt *ppStmt;
        if(sqlite3_prepare_v2(dbsql,[Query UTF8String],-1,&ppStmt,nil)==SQLITE_OK)
        {
            while(sqlite3_step(ppStmt)==SQLITE_ROW)
            {
                NSString *stid=[NSString stringWithFormat:@"%s",sqlite3_column_text(ppStmt,0)];
                NSString *stnm=[NSString stringWithFormat:@"%s",sqlite3_column_text(ppStmt,1)];
                NSString *stct=[NSString stringWithFormat:@"%s",sqlite3_column_text(ppStmt,2)];
                NSString *stedu=[NSString stringWithFormat:@"%s",sqlite3_column_text(ppStmt,3)];
                
                [dictmute setObject:stid forKey:@"stid"];
                [dictmute setObject:stnm forKey:@"stnm"];
                [dictmute setObject:stct forKey:@"stct"];
                [dictmute setObject:stedu forKey:@"stedu"];
                
                [result addObject:[dictmute copy]];
            }
        }
        sqlite3_finalize(ppStmt);
    }
    sqlite3_close(dbsql);
    return result;
}
@end
