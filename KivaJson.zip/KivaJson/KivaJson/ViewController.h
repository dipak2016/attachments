//
//  ViewController.h
//  KivaJson
//
//  Created by MAC on 8/18/15.
//  Copyright (c) 2015 ___FULLUSERNAME___. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray *arrmain;
}
@end
