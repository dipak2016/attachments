//
//  ViewController.m
//  KivaJson
//
//  Created by MAC on 8/18/15.
//  Copyright (c) 2015 ___FULLUSERNAME___. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    arrmain=[[NSMutableArray alloc]init];
    
    NSURL *url=[NSURL URLWithString:@"http://api.kivaws.org/v1/loans/newest.json"];
    
    NSData *data=[NSData dataWithContentsOfURL:url];
    
    NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
    /*
    for (id ids in dict)
    {
        NSLog(@"KEY : %@ VALUE : %@",ids,[dict objectForKey:ids]);
    }
    */
    
    NSMutableArray *arrmute=[[NSMutableArray alloc]initWithArray:[dict objectForKey:@"loans"]];
    
    for (int i=0;i<arrmute.count;i++)
    {
        //NSLog(@"INDEX : %d VALUE : %@",i,[arrmute objectAtIndex:i]);
        
        NSString *activity=[[arrmute objectAtIndex:i]objectForKey:@"activity"];
        NSString *name=[[arrmute objectAtIndex:i]objectForKey:@"name"];
         NSString *loan_amount=[[arrmute objectAtIndex:i]objectForKey:@"loan_amount"];
         NSString *funded_amount=[[arrmute objectAtIndex:i]objectForKey:@"funded_amount"];
         NSString *country=[[[arrmute objectAtIndex:i]objectForKey:@"location"]objectForKey:@"country"];
        NSLog(@"%@ FROM %@ ACTIVITY %@ NEEDS %.1f$ TO PURSE THEIR DREAM",name,country,activity,[loan_amount floatValue]-[funded_amount floatValue]);
        
        [arrmain addObject:[NSString stringWithFormat:@"%@ FROM %@ ACTIVITY %@ NEEDS %.1f$ TO PURSE THEIR DREAM",name,country,activity,[loan_amount floatValue]-[funded_amount floatValue]]];
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrmain.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=nil;
    cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    cell.textLabel.text=[arrmain objectAtIndex:indexPath.row];
    return cell;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
