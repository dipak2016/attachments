//
//  ViewController.m
//  MailSendWebService
//
//  Created by MAC on 9/10/15.
//  Copyright (c) 2015 ___FULLUSERNAME___. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    NSString *soapmsg=[[NSString alloc]initWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">                       <soap:Body><MailSend xmlns=\"http://tempuri.org/\"><emailTo>%@</emailTo><subject>%@</subject><body>%@</body></MailSend></soap:Body></soap:Envelope>",@"nkajudia2008@gmail.com",@"Testing Webservice",@"Hello web Service"];
    NSURL *url=[[NSURL alloc]initWithString:@"http://ios8192014.somee.com/webservice.asmx?op=MailSend"];
    NSMutableURLRequest *req=[[NSMutableURLRequest alloc]initWithURL:url];
    [req setValue:@"ios8192014.somee.com" forHTTPHeaderField:@"Host"];
    [req setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [req setValue:[NSString stringWithFormat:@"%d",soapmsg.length] forHTTPHeaderField:@"Content-Length"];
    [req setValue:@"http://tempuri.org/MailSend" forHTTPHeaderField:@"SOAPAction"];
    [req setHTTPMethod:@"POST"];
    [req setHTTPBody:[soapmsg dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLConnection *con=[[NSURLConnection alloc]initWithRequest:req delegate:self];
    if (con)
    {
        
    }
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    
}
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"%@",error);
}
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
