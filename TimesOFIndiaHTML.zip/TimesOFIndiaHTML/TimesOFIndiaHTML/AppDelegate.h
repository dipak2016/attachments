//
//  AppDelegate.h
//  TimesOFIndiaHTML
//
//  Created by MAC on 9/24/15.
//  Copyright (c) 2015 ___FULLUSERNAME___. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property(retain,nonatomic)ViewController *vc;
@end
