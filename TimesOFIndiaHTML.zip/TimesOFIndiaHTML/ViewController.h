//
//  ViewController.h
//  TimesOFIndiaHTML
//
//  Created by MAC on 9/24/15.
//  Copyright (c) 2015 MAC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<NSXMLParserDelegate,UITableViewDataSource,UITableViewDelegate>
{
    NSString *elemnt;
    NSMutableString *description;
    NSMutableArray *arrmain;
}
@end
