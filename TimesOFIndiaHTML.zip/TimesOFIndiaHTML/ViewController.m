//
//  ViewController.m
//  TimesOFIndiaHTML
//
//  Created by MAC on 9/24/15.
//  Copyright (c) 2015 MAC. All rights reserved.
//

#import "ViewController.h"
#import "TFHpple.h"
@interface ViewController ()

@end

@implementation ViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    arrmain=[[NSMutableArray alloc]init];
    
    NSURL *url=[[NSURL alloc]initWithString:@"http://timesofindia.feedsportal.com/c/33039/f/533965/index.rss"];
    NSXMLParser *parser=[[NSXMLParser alloc]initWithContentsOfURL:url];
    parser.delegate=self;
    [parser parse];
}
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
    elemnt=elementName;
    if ([elementName isEqualToString:@"item"])
    {
        description=[[NSMutableString alloc]init];
    }
}
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    if ([elemnt isEqualToString:@"description"])
    {
        [description appendString:string];
    }
}
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    if ([elementName isEqualToString:@"item"])
    {
        NSData *tutorialsHtmlData = [description dataUsingEncoding:NSUTF8StringEncoding];
        
        // 2
        TFHpple *tutorialsParser = [TFHpple hppleWithHTMLData:tutorialsHtmlData];
        
        // 3
        NSString *tutorialsXpathQueryString = @"//img";
        
        NSArray *tutorialsNodes = [tutorialsParser searchWithXPathQuery:tutorialsXpathQueryString];
        
        for (TFHppleElement *element in tutorialsNodes)
        {
            if ([[[element objectForKey:@"src"]pathExtension]isEqualToString:@"cms"])
            {
                //NSLog(@"%@",[element objectForKey:@"src"]);
                [arrmain addObject:[element objectForKey:@"src"]];
            }
        }
        
    }
}
- (void)parserDidEndDocument:(NSXMLParser *)parser
{
    for (int i=0;i<arrmain.count;i++)
    {
        NSLog(@"INDEX:%d VALUE:%@",i,[arrmain objectAtIndex:i]);
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrmain.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=nil;
    cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    NSURL *url=[NSURL URLWithString:[arrmain objectAtIndex:indexPath.row]];
    NSData *data=[NSData dataWithContentsOfURL:url];
    cell.imageView.image=[UIImage imageWithData:data];
    return cell;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
