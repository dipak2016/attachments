//
//  ViewController.h
//  W3schoolWebService
//
//  Created by MAC on 9/10/15.
//  Copyright (c) 2015 ___FULLUSERNAME___. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<NSURLConnectionDelegate,NSXMLParserDelegate>
{
    NSMutableData *datamute;
    NSString *elemntnm;
}
@property (weak, nonatomic) IBOutlet UITextField *txt_cel;
- (IBAction)btn_action:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *lbl_nm;
@end
