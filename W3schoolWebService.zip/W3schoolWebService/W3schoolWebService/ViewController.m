//
//  ViewController.m
//  W3schoolWebService
//
//  Created by MAC on 9/10/15.
//  Copyright (c) 2015 ___FULLUSERNAME___. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize lbl_nm,txt_cel;
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)btn_action:(id)sender
{
    NSString *soapmsg=[[NSString alloc]initWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">                       <soap:Body><CelsiusToFahrenheit xmlns=\"http://www.w3schools.com/webservices/\"><Celsius>%@</Celsius></CelsiusToFahrenheit></soap:Body></soap:Envelope>",txt_cel.text];
    
    NSURL *url=[[NSURL alloc]initWithString:@"http://www.w3schools.com/webservices/tempconvert.asmx?op=CelsiusToFahrenheit"];
    
    NSMutableURLRequest *req=[[NSMutableURLRequest alloc]initWithURL:url];
    [req setValue:@"www.w3schools.com" forHTTPHeaderField:@"Host"];
    [req setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [req setValue:[NSString stringWithFormat:@"%d",soapmsg.length] forHTTPHeaderField:@"Content-Length"];
    [req setValue:@"http://www.w3schools.com/webservices/CelsiusToFahrenheit" forHTTPHeaderField:@"SOAPAction"];
    [req setHTTPMethod:@"POST"];
    [req setHTTPBody:[soapmsg dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSURLConnection *con=[[NSURLConnection alloc]initWithRequest:req delegate:self];
    if (con)
    {
        datamute=[[NSMutableData alloc]init];
    }
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    datamute.length=0;
}
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"%@",error);
}
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [datamute appendData:data];
}
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    //this coding is only for checking purpose
    /*
    NSString *str=[[NSString alloc]initWithData:datamute encoding:NSUTF8StringEncoding];
    NSLog(@"%@",str);
    */
    NSXMLParser *parser=[[NSXMLParser alloc]initWithData:datamute];
    parser.delegate=self;
    [parser parse];
}
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
    elemntnm=elementName;
}
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    if ([elemntnm isEqualToString:@"CelsiusToFahrenheitResult"])
    {
        NSLog(@"%@",string);
        if (string.length>0)
        {
            lbl_nm.text=string;
        }
    }
}
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    
}
- (void)parserDidEndDocument:(NSXMLParser *)parser
{
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
