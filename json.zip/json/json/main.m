//
//  main.m
//  json
//
//  Created by MAC on 8/20/15.
//  Copyright (c) 2015 MAC. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool
    {
        NSString *strformat=[NSString stringWithFormat:@"http://api.openweathermap.org/data/2.5/weather?q=rajkot"];
        
        NSURL *url=[NSURL URLWithString:strformat];
        
        NSData *data=[NSData dataWithContentsOfURL:url];
        
        NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
        /*
        for (id ids in dict)
        {
            NSLog(@"KEY:%@ VALUE:%@",ids,[dict objectForKey:ids]);
        }
        */
       
        NSArray *arr=[dict objectForKey:@"weather"];
        /*
        for (int i=0;i<arr.count;i++)
        {
            NSLog(@"INDEX:%d VALUE:%@",i,[arr objectAtIndex:i]);
        }
        */
    NSLog(@"%@",[[arr objectAtIndex:0]objectForKey:@"description"]);
        
    }
    return 0;
}

