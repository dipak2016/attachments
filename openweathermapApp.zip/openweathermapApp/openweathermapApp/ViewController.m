//
//  ViewController.m
//  openweathermapApp
//
//  Created by MAC on 8/20/15.
//  Copyright (c) 2015 ___FULLUSERNAME___. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize txt_loc,mapvw;
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(MKAnnotationView *)mapView:(MKMapView *)mV viewForAnnotation:(id <MKAnnotation>)annotation
{
    MKAnnotationView *pinView = nil;
    if(annotation != mapvw.userLocation)
    {
        static NSString *defaultPinID = @"com.invasivecode.pin";
        pinView = (MKAnnotationView *)[mapvw dequeueReusableAnnotationViewWithIdentifier:defaultPinID];
        if ( pinView == nil )
            pinView = [[MKAnnotationView alloc]
                       initWithAnnotation:annotation reuseIdentifier:defaultPinID];
        
        //pinView.pinColor = MKPinAnnotationColorGreen;
        pinView.canShowCallout = YES;
        //pinView.animatesDrop = YES;
        pinView.image = [UIImage imageNamed:@"1440071195_map-marker"];    //as suggested by Squatch
    }
    else {
        [mapvw.userLocation setTitle:@"I am here"];
    }
    return pinView;
}
- (IBAction)btn_submit:(id)sender
{
    [self.view endEditing:YES];
    
    NSString *strformat=[NSString stringWithFormat:@"http://api.openweathermap.org/data/2.5/weather?q='%@'",[txt_loc.text stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    
    NSURL *url=[NSURL URLWithString:strformat];
    
    NSData *data=[NSData dataWithContentsOfURL:url];
    
    NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
    /*
    for (id ids in dict)
    {
        NSLog(@"KEY:%@ VALUE:%@",ids,[dict objectForKey:ids]);
    }
    */
    
    NSArray *arr=[dict objectForKey:@"weather"];
    /*
     for (int i=0;i<arr.count;i++)
     {
     NSLog(@"INDEX:%d VALUE:%@",i,[arr objectAtIndex:i]);
     }
     */
    //NSLog(@"%@",[[arr objectAtIndex:0]objectForKey:@"description"]);

    
    NSLog(@"lat:%@",[[dict objectForKey:@"coord"]objectForKey:@"lat"]);
    NSLog(@"lon:%@",[[dict objectForKey:@"coord"]objectForKey:@"lon"]);
    
    CLLocationCoordinate2D loc;
    loc.latitude=[[[dict objectForKey:@"coord"]objectForKey:@"lat"]floatValue];
    loc.longitude=[[[dict objectForKey:@"coord"]objectForKey:@"lon"]floatValue];
    
    MKCoordinateRegion regin;
    regin.span.latitudeDelta=0.1;
    regin.span.longitudeDelta=0.1;
    regin.center=loc;
    
    MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
    [annotation setCoordinate:loc];
    [annotation setTitle:[[arr objectAtIndex:0]objectForKey:@"description"]]; //You can set the subtitle too
    [mapvw addAnnotation:annotation];
    
    [mapvw setRegion:regin animated:YES];
    [mapvw regionThatFits:regin];

}
@end
