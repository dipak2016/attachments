//
//  ViewController.h
//  ovohome
//
//  Created by MAC on 8/11/15.
//  Copyright (c) 2015 ___FULLUSERNAME___. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<NSXMLParserDelegate,UITableViewDataSource,UITableViewDelegate>
{
    NSMutableString *st_cover;
    NSMutableArray *arrmute;
    NSString *elemntnm;
}
@end
