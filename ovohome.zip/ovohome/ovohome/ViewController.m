//
//  ViewController.m
//  ovohome
//
//  Created by MAC on 8/11/15.
//  Copyright (c) 2015 ___FULLUSERNAME___. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    arrmute=[[NSMutableArray alloc]init];
    NSXMLParser *parser=[[NSXMLParser alloc]initWithContentsOfURL:[NSURL URLWithString:@"http://www.ovohome.com.hk/xml/editorial.xml"]];
    parser.delegate=self;
    [parser parse];
}
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
    elemntnm=elementName;
    if([elementName isEqualToString:@"issue"])
    {
        st_cover=[[NSMutableString alloc]init];
    }
}
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    if([elemntnm isEqualToString:@"cover"])
    {
        [st_cover appendString:string];
    }
}
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    if([elementName isEqualToString:@"issue"])
    {
       [st_cover insertString:@"http://www.ovohome.com.hk/" atIndex:0];
        [arrmute addObject:st_cover];
    }
}
- (void)parserDidEndDocument:(NSXMLParser *)parser
{
    /*
    for (int i=0;i<arrmute.count;i++)
    {
        NSLog(@"INDEX:%d VALUE:%@",i,[arrmute objectAtIndex:i]);
    }
    */ 
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrmute.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=nil;
    cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    
    NSLog(@"%@",[[[arrmute objectAtIndex:indexPath.row]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]stringByReplacingOccurrencesOfString:@"%0A%20%20%20%20%20%20%20%20" withString:@""]);
    
    NSURL *url=[[NSURL alloc]initWithString:[[[arrmute objectAtIndex:indexPath.row]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]stringByReplacingOccurrencesOfString:@"%0A%20%20%20%20%20%20%20%20" withString:@""]];
    
    NSData *data=[[NSData alloc]initWithContentsOfURL:url];
    
    cell.imageView.image=[UIImage imageWithData:data];
    
    return cell;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
