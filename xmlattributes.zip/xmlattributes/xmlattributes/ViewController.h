//
//  ViewController.h
//  xmlattributes
//
//  Created by MAC on 8/15/15.
//  Copyright (c) 2015 ___FULLUSERNAME___. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<NSXMLParserDelegate>
{
    NSString *elemntnm;
    NSString *stval;
    NSString *strefnm;
    NSString *strefpurpose;
}
@end
