//
//  ViewController.m
//  xmlattributes
//
//  Created by MAC on 8/15/15.
//  Copyright (c) 2015 ___FULLUSERNAME___. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    stval=@"";
    NSURL *url=[[NSURL alloc]initWithString:@"https://www.khronos.org/registry/cl/sdk/1.0/docs/man/attributes-variables.xml"];
    NSXMLParser *parser=[[NSXMLParser alloc]initWithContentsOfURL:url];
    parser.delegate=self;
    [parser parse];
}
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
    elemntnm=elementName;
    if([elementName isEqualToString:@"refnamediv"])
    {
        if ([[attributeDict objectForKey:@"id"]isEqualToString:@"Attributes of Variables"])
        {
            stval=[stval stringByAppendingFormat:@"TITLE : %@ \n",[attributeDict objectForKey:@"id"]];
            strefnm=@"";
            strefpurpose=@"";
        }
    }
    
    
}
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    if([elemntnm isEqualToString:@"refname"])
    {
        //NSLog(@"foundCharacters:nm:%@",string);
    strefnm=[strefnm stringByAppendingFormat:@"%@",string];
    }
    if([elemntnm isEqualToString:@"refpurpose"])
    {
        //NSLog(@"foundCharacters:pur:%@",string);
    strefpurpose=[strefpurpose stringByAppendingFormat:@"%@",string];
    }
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    if([elementName isEqualToString:@"refnamediv"])
    {
        //NSLog(@"didEndElement:nm:%@",strefnm);
        //NSLog(@"didEndElement:pur:%@",strefpurpose);
        stval=[stval stringByAppendingFormat:@"strefnm:%@ \n strefpurpose:%@",strefnm,strefpurpose];
        NSLog(@"STVAL:%@",stval);
    }
}
- (void)parserDidEndDocument:(NSXMLParser *)parser
{
    //NSLog(@"%@",stval);
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
